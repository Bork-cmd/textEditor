﻿Imports System.IO

Public Class frmTextEditor

    ' filePath variable
    Dim filePath As String = String.Empty

    ' open file variables
    Dim openFileDia As New OpenFileDialog
    Dim fileDia As String

    ' save file variables
    Dim openSaveDia As New SaveFileDialog
    Dim SaveDia As String


#Region "File"
    ''' <summary>
    ''' Creates a new empty file
    ''' </summary>
    Private Sub NewFile(sender As Object, e As EventArgs) Handles mnuNew.Click, MyBase.Load

        ' Clears the textbox
        txtWrite.Text = ""

        ' Clears the file path
        filePath = String.Empty

    End Sub

    ''' <summary>
    ''' Opens file selected by the user
    ''' </summary>
    Private Sub mnuOpen_Click(sender As Object, e As EventArgs) Handles mnuOpen.Click

        openFileDia.Filter = "Text Files (.txt)|*.txt*"
        openFileDia.Title = "Open A File"

        openFileDia.ShowDialog()
        filePath = openFileDia.FileName

        Dim sr As New StreamReader(filePath)
        txtWrite.Text = sr.ReadToEnd()
        sr.Close()
    End Sub

    ''' <summary>
    ''' Saves the file as the name the user enters
    ''' </summary>
    Private Sub mnuSaveAs_Click(sender As Object, e As EventArgs) Handles mnuSaveAs.Click

        openSaveDia.Filter = "Text Files (.txt)|*.txt*"
        openSaveDia.Title = "Save Files As..."

        openSaveDia.ShowDialog()
        filePath = openSaveDia.FileName

        Dim sw As New StreamWriter(filePath)
        sw.Write(txtWrite.Text)
        sw.Close()
    End Sub

    ''' <summary>
    ''' Saves the file
    ''' </summary>
    Private Sub mnuSave_Click(sender As Object, e As EventArgs) Handles mnuSave.Click

        If filePath = String.Empty Then

            ' if a filepath is not specified
            mnuSaveAs_Click(sender, e)
        Else
            ' if a filepath is specified
            Dim sw As New StreamWriter(filePath)
            sw.Write(txtWrite.Text)
            sw.Close()
        End If

    End Sub

    ''' <summary>
    ''' Closes the program
    ''' </summary>
    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub

#End Region

#Region "Edit"

    ''' <summary>
    ''' Copies the text in the file
    ''' </summary>
    Private Sub mnuCopy_Click(sender As Object, e As EventArgs) Handles mnuCopy.Click
        txtWrite.Copy()
    End Sub

    ''' <summary>
    ''' Cuts the text selected in the file
    ''' </summary>
    Private Sub mnuCut_Click(sender As Object, e As EventArgs) Handles mnuCut.Click
        txtWrite.Cut()
    End Sub

    ''' <summary>
    ''' Pastes whats saved on the clipboard
    ''' </summary>
    Private Sub mnuPaste_Click(sender As Object, e As EventArgs) Handles mnuPaste.Click
        txtWrite.Paste()
    End Sub

    ''' <summary>
    ''' Undoes the last edit
    ''' </summary>
    Private Sub mnuUndo_Click(sender As Object, e As EventArgs) Handles mnuUndo.Click
        txtWrite.Undo()
    End Sub

#End Region
#Region "Help"
    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click

    End Sub

#End Region


End Class
